﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace App
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            SqlConnection connection = DBConnection.GetDBConnection();
            MessageBox.Show("Conectado!");
            SqlCommand command = new SqlCommand("SELECT * FROM persona", connection);
            SqlDataReader dataReader = command.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(dataReader);
            dataGridView1.DataSource = dataTable;
            connection.Close();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            AgregarRegistro();
            CargarDatos();
        }

        private void AgregarRegistro()
        {
            using (SqlConnection conexion = DBConnection.GetDBConnection())
            {

                string query = "INSERT INTO persona (nombre, apellido, edad) VALUES (@nombre, @apellido, @edad)";
                SqlCommand comando = new SqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@nombre", txtNombre.Text);
                comando.Parameters.AddWithValue("@apellido", txtApellido.Text);
                comando.Parameters.AddWithValue("@edad", int.Parse(txtEdad.Text));

                comando.ExecuteNonQuery();
            }
        }

        private void CargarDatos()
        {
            using (SqlConnection conexion = DBConnection.GetDBConnection())
            {

                string query = "SELECT * FROM persona";
                SqlDataAdapter adaptador = new SqlDataAdapter(query, conexion);
                DataTable datos = new DataTable();
                adaptador.Fill(datos);

                dataGridView1.DataSource = datos;
            }
        }

        private void Eliminar()
        {
            using (SqlConnection conexion = DBConnection.GetDBConnection())
            {
                string query = "DELETE FROM persona WHERE id = @id";
                SqlCommand comando = new SqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@id", int.Parse(txtEliminar.Text));

                comando.ExecuteNonQuery();
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNombre.Clear();
            txtApellido.Clear();
            txtEdad.Clear();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            Eliminar();
            CargarDatos();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            EditarRegistro();
            CargarDatos();
        }

        private void EditarRegistro()
        {
            using (SqlConnection conexion = DBConnection.GetDBConnection())
            {

                string query = "UPDATE persona SET nombre=@nombre, apellido=@apellido, edad=@edad WHERE id=@id";
                SqlCommand comando = new SqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@id", int.Parse(txtEliminar.Text));
                comando.Parameters.AddWithValue("@nombre", txtNombre.Text);
                comando.Parameters.AddWithValue("@apellido", txtApellido.Text);
                comando.Parameters.AddWithValue("@edad", int.Parse(txtEdad.Text));

                comando.ExecuteNonQuery();
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
